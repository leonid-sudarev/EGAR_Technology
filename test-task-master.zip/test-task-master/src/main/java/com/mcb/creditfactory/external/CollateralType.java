package com.mcb.creditfactory.external;

public enum CollateralType {
    CAR,
    AIRPLANE,
}
